

/* 
 * File: LCD.c  
 * Se utiliz? y se adaptaron las librer?as de Ligo George 
 * de la p?gina www.electrosome.com
 * Enlace: https://electrosome.com/lcd-pic-mplab-xc8/
 * Revision history: 
 */

//LCD Functions Developed by electroSome

#include "LCD_8.h"
#include <xc.h> // include processor files - each processor file is guarded.  
#include <pic16f887.h>
#include <stdint.h>

#ifndef _XTAL_FREQ
#define _XTAL_FREQ 8000000
#endif



void Lcd_Port(char a) {
    PORTD = a;
}

void Lcd_Cmd(char a) { //bien
    RS = 0; // => RS = 0 // Dato en el puerto lo va interpretar como comando
    Lcd_Port(a);
    EN = 1; // => E = 1
    __delay_ms(4);
    //EN = 0; // => E = 0
    EN = 0;
}

void Lcd_Clear(void) { //ya
    Lcd_Cmd(0);
    Lcd_Cmd(1);
}

void Lcd_Set_Cursor(char a, char b) { //ya
    char direccion;
    if (a == 1) {
        direccion = 0x80 + b - 1; //1xxx xxxx comando: direccion DDRAM; x= direcci?n
        Lcd_Cmd(direccion);
    } else if (a == 2) {
        direccion = 0xC0 + b - 1; 
        Lcd_Cmd(direccion);
    }
}

void Lcd_Init(void) { //ya
    Lcd_Port(0x00);
    __delay_ms(20);
    Lcd_Cmd(0x30);
    __delay_ms(5);
    Lcd_Cmd(0x30);
    __delay_ms(11);
    Lcd_Cmd(0x30);
    /////////////////////////////////////////////////////
    Lcd_Cmd(0x3C);
    Lcd_Cmd(0x0C);
    Lcd_Cmd(0x01);
    Lcd_Cmd(0x06);
}

void Lcd_Write_Char(char a) { //ya
    RS = 1; // => RS = 1
    Lcd_Port(a); //Data transfer
    EN = 1;
    __delay_us(40);
    EN = 0;

}

void Lcd_Write_String(char *a) {
    int i;
    for (i = 0; a[i] != '\0'; i++)
        Lcd_Write_Char(a[i]);
}

void Lcd_Shift_Right(void) {
    Lcd_Cmd(0x01);
    Lcd_Cmd(0x0C);
}

void Lcd_Shift_Left(void) {
    Lcd_Cmd(0x01);
    Lcd_Cmd(0x08);
}

//LIBRER?AS*************************************************************************************
void ioc_init (char pin){ //LIBRER?A PARA ELEGIR EL PIN DEL PUERTO B PARA HABILITARLO COMO ENTRADA
    INTCONbits.RBIE = 1;//HABILITA LA INTERRUPCI?N
    INTCONbits.RBIF = 0; //LIMPIA LA BANDERA
    OPTION_REGbits.nRBPU = 0; 
    
    switch (pin)
    {
        case 0:
            TRISBbits.TRISB0 = 1; //HABILITA EL PUERTO 1 COMO ENTRADA
            PORTBbits.RB0 = 0; //LIMPIA EL PUERTO
          
            WPUBbits.WPUB0 = 1; //HABILITA EL PULL UP DEL PUERTO B EN EL PIN 0
            IOCBbits.IOCB0 = 1; //HABILITA LA INTERRUPCI?N DEL PIN 0
            break;
            
        case 1:
            TRISBbits.TRISB1 = 1; //HABILITA EL PUERTO 1 COMO ENTRADA
            PORTBbits.RB1 = 0; //LIMPIA EL PUERTO
          
            WPUBbits.WPUB1 = 1; //HABILITA EL PULL UP DEL PUERTO B EN EL PIN 1
            IOCBbits.IOCB1 = 1; //HABILITA LA INTERRUPCI?N DEL PIN 1
            break;
            
        case 2:
            TRISBbits.TRISB2 = 1; //HABILITA EL PUERTO 1 COMO ENTRADA
            PORTBbits.RB2 = 0; //LIMPIA EL PUERTO
          
            WPUBbits.WPUB2 = 1; //HABILITA EL PULL UP DEL PUERTO B EN EL PIN 2
            IOCBbits.IOCB2 = 1; //HABILITA LA INTERRUPCI?N DEL PIN 2
            break;
            
        case 3:
            TRISBbits.TRISB3 = 1; //HABILITA EL PUERTO 1 COMO ENTRADA
            PORTBbits.RB3 = 0; //LIMPIA EL PUERTO
          
            WPUBbits.WPUB3 = 1; //HABILITA EL PULL UP DEL PUERTO B EN EL PIN 3
            IOCBbits.IOCB3 = 1; //HABILITA LA INTERRUPCI?N DEL PIN 3
            break;
            
        case 4:
            TRISBbits.TRISB4 = 1; //HABILITA EL PUERTO 1 COMO ENTRADA
            PORTBbits.RB4 = 0; //LIMPIA EL PUERTO
          
            WPUBbits.WPUB4 = 1; //HABILITA EL PULL UP DEL PUERTO B EN EL PIN 4
            IOCBbits.IOCB4 = 1; //HABILITA LA INTERRUPCI?N DEL PIN 4
            break;
            
        case 5:
            TRISBbits.TRISB5 = 1; //HABILITA EL PUERTO 1 COMO ENTRADA
            PORTBbits.RB5 = 0; //LIMPIA EL PUERTO
          
            WPUBbits.WPUB5 = 1; //HABILITA EL PULL UP DEL PUERTO B EN EL PIN 5
            IOCBbits.IOCB5 = 1; //HABILITA LA INTERRUPCI?N DEL PIN 5
            break;
            
        case 6:
            TRISBbits.TRISB6 = 1; //HABILITA EL PUERTO 1 COMO ENTRADA
            PORTBbits.RB6 = 0; //LIMPIA EL PUERTO
          
            WPUBbits.WPUB6 = 1; //HABILITA EL PULL UP DEL PUERTO B EN EL PIN 6
            IOCBbits.IOCB6 = 1; //HABILITA LA INTERRUPCI?N DEL PIN 6
            break;
            
        case 7:
            TRISBbits.TRISB7 = 1; //HABILITA EL PUERTO 1 COMO ENTRADA
            PORTBbits.RB7 = 0; //LIMPIA EL PUERTO
          
            WPUBbits.WPUB7 = 1; //HABILITA EL PULL UP DEL PUERTO B EN EL PIN 7
            IOCBbits.IOCB7 = 1; //HABILITA LA INTERRUPCI?N DEL PIN 7
            break;
            
        default:
            //PORTA++;
            TRISB = 0b11111111;
            PORTB = 0x00;
            WPUB = 0b11111111;
            IOCB = 0b11111111;
            break;
    }
}
